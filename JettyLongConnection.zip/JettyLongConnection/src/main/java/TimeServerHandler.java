import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;
import io.netty.util.CharsetUtil;

public class TimeServerHandler extends ChannelInboundHandlerAdapter {
    private boolean isWrite = true;

    @Override
    public void channelWritabilityChanged(ChannelHandlerContext ctx) throws Exception {
        if (ctx.channel().isWritable()) {
            this.isWrite = true;
        } else {
            this.isWrite = false;
        }
    }

    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
        if (evt instanceof IdleStateEvent) {
            IdleStateEvent idleStateEvent = (IdleStateEvent) evt;
            if (idleStateEvent.state() == IdleState.WRITER_IDLE) {
                System.out.println("server write idle: send heartbeat to client");
                ctx.writeAndFlush(Unpooled.copiedBuffer("server heartbeat to client", CharsetUtil.UTF_8)).addListener(ChannelFutureListener.CLOSE_ON_FAILURE);
            }
        }

        super.userEventTriggered(ctx, evt);
    }

    @Override
    public void channelActive(final ChannelHandlerContext ctx) throws Exception { // (1)
        int i = 0;
        while (this.isWrite) {
            i ++;
            final ByteBuf byteBuf = ctx.alloc().buffer(8);
            byteBuf.writeBytes("你好，欢迎建立长连接".getBytes());
            ChannelFuture cf = ctx.writeAndFlush(byteBuf, ctx.channel().newPromise());
            System.out.println("TimeServerHandler，有新连接");
            if ( i % 100 == 0) {
                cf.sync();
            }

            if (i % 10000 == 0) {
                i = 0;
                Thread.sleep(1000);
            }
        }
    }
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        cause.printStackTrace();
        ctx.close();
    }
}