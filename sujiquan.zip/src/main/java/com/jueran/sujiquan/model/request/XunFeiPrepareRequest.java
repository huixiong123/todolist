package com.jueran.sujiquan.model.request;

public class XunFeiPrepareRequest {
    private String app_id = "57e39c95";
    private String signa;
    private String ts;
    private String file_len;
    private String file_name;
    private String slice_num;
    private String lfasr_type;
    private String has_participle;
    private String max_alternatives;
    private String speaker_number;
    private String has_seperate;
    private String role_type;
    private String language;
    private String bd;
}
