package com.jueran.sujiquan.model.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@ToString
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class GroupSendFileUploadBody {
    private String taskName;
    private Date sendDateTime;
    private String appName;
    private String schedule;
}
