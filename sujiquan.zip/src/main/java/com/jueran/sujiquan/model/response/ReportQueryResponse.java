package com.jueran.sujiquan.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class ReportQueryResponse {
    private String applicationName;
    private String caseNoExt;
    private String mobile;
    private String answer;
    private String sendTime;
    private String answerTime;
}
