package com.jueran.sujiquan.log;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JRLog {
    private Logger logger;
    public JRLog(Class cls) {
        logger = LoggerFactory.getLogger(cls);
    }
    public void info(String msg) {
        logger.info(msg);
    }

    public void info(Throwable ex) {
        info(ex.getMessage(), ex);
    }

    public void info(String msg, Throwable ex) {
        logger.info(msg, ex);
    }

    public void error(String msg) {
        logger.error(msg);
    }

    public void error(Throwable ex) {
        info(ex.getMessage(), ex);
    }

    public void error(String msg, Throwable ex) {
        logger.error(msg, ex);
    }

    public void warn(String msg) {
        logger.warn(msg);
    }

    public void warn(Throwable ex) {
        info(ex.getMessage(), ex);
    }

    public void warn(String msg, Throwable ex) {
        logger.warn(msg, ex);
    }

    public void debug(String msg) {
        logger.debug(msg);
    }

}
