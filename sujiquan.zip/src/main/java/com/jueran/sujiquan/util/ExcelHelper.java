package com.jueran.sujiquan.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import com.jueran.sujiquan.model.response.ReportQueryResponse;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ExcelHelper {
    public static String TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    static String[] HEADERs = { "applicationName", "caseIdExt", "mobile", "answer", "sendTime", "answerTime" };
    static String SHEET = "ReportQueryResponse";

    public static ByteArrayInputStream toExcel(List<ReportQueryResponse> ReportQueryResponses) {

        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
            Sheet sheet = workbook.createSheet(SHEET);

            // Header
            Row headerRow = sheet.createRow(0);

            for (int col = 0; col < HEADERs.length; col++) {
                Cell cell = headerRow.createCell(col);
                cell.setCellValue(HEADERs[col]);
            }

            int rowIdx = 1;
            for (ReportQueryResponse queryResponse : ReportQueryResponses) {
                Row row = sheet.createRow(rowIdx++);

                row.createCell(0).setCellValue(queryResponse.getApplicationName());
                row.createCell(1).setCellValue(queryResponse.getCaseNoExt());
                row.createCell(2).setCellValue(queryResponse.getMobile());
                row.createCell(3).setCellValue(queryResponse.getAnswer());
                row.createCell(4).setCellValue(queryResponse.getSendTime());
                row.createCell(5).setCellValue(queryResponse.getAnswerTime());
            }

            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            throw new RuntimeException("fail to import data to Excel file: " + e.getMessage());
        }
    }
}
