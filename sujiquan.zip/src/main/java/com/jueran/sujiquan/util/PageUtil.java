package com.jueran.sujiquan.util;


import com.github.pagehelper.PageHelper;
import com.google.common.base.CaseFormat;
import org.springframework.data.domain.Pageable;

import java.util.stream.Collectors;

public class PageUtil {
    public static void startPage(Pageable pageable) {
        PageHelper.startPage(pageable.getPageNumber(), pageable.getPageSize(),
                pageable.getSort().stream().map(order -> CaseFormat.LOWER_CAMEL.to(CaseFormat.LOWER_UNDERSCORE, order.getProperty()) + " " + order.getDirection()).collect(Collectors.joining(",")));
    }
}
