package com.jueran.sujiquan.util;

import org.apache.commons.lang3.StringUtils;

import java.beans.PropertyEditorSupport;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Random;

/**
 * Description:时间操作定义类
 * User: Ryan
 * Time: 2018/1/29 14:26
 */
public class DateUtils extends PropertyEditorSupport {
    public static final SimpleDateFormat date_sdf = new SimpleDateFormat("yyyy-MM-dd");
    // 以毫秒表示的时间
    private static final long DAY_IN_MILLIS = 86400000;
    private static final long HOUR_IN_MILLIS = 3600000;
    private static final long MINUTE_IN_MILLIS = 60000;
    private static final long SECOND_IN_MILLIS = 1000;
    // 指定模式的时间格式
    private static SimpleDateFormat getSDFormat(String pattern) {
        return new SimpleDateFormat(pattern);
    }

    private static final com.jueran.sujiquan.log.JRLog LOG = new com.jueran.sujiquan.log.JRLog(DateUtils.class);
    /**
     * 当前日历，这里用中国时间表示
     * @return 以当地时区表示的系统当前日历
     */
    public static Calendar getCalendar() {
        return Calendar.getInstance();
    }

    /**
     * 指定毫秒数表示的日历
     * @param millis 毫秒数
     * @return 指定毫秒数表示的日历
     */
    public static Calendar getCalendar(long millis) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date(millis));
        return cal;
    }

    /**
     * 当前日期
     * @return 系统当前时间
     */
    public static Date getDate() {
        return new Date();
    }

    /**
     * 指定毫秒数表示的日期
     * @param millis 毫秒数
     * @return 指定毫秒数表示的日期
     */
    public static Date getDate(long millis) {
        return new Date(millis);
    }

    /**
     * 字符串转换成日期
     * @param str
     * @param sdf
     * @return
     */
    public static Date strToDate(String str, SimpleDateFormat sdf) {
        if (null == str || "".equals(str)) {
            return null;
        }
        Date date = null;
        try {
            date = sdf.parse(str);
            return date;
        } catch (ParseException e) {
            LOG.error(e);
        }
        return null;
    }

    /**
     * 格式化时间
     * @param date
     * @param format
     * @return
     */
    public static String dateformat(String date,String format)
    {
        SimpleDateFormat sformat = new SimpleDateFormat(format);
        Date _date=null;
        try {
            _date=sformat.parse(date);
        } catch (ParseException e) {
            LOG.error(e);
        }
        return sformat.format(_date);
    }
    /**
     * 日期转换为字符串
     * @return 字符串
     */
    public static String dateToStr(Date date, SimpleDateFormat date_sdf) {
        return date_sdf.format(date);
    }
    /**
     * 日期转换为字符串
     * @return 字符串
     */
    public static String getDate(String format) {
        Date date=new Date();
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        return sdf.format(date);
    }

    /**
     * 指定毫秒数的时间戳
     * @param millis 毫秒数
     * @return 指定毫秒数的时间戳
     */
    public static Timestamp getTimestamp(long millis) {
        return new Timestamp(millis);
    }

    /**
     * 以字符形式表示的时间戳
     * @param time 毫秒数
     * @return 以字符形式表示的时间戳
     */
    public static Timestamp getTimestamp(String time) {
        return new Timestamp(Long.parseLong(time));
    }

    /**
     * 系统当前的时间戳
     * @return 系统当前的时间戳
     */
    public static Timestamp getTimestamp() {
        return new Timestamp(new Date().getTime());
    }

    /**
     * 指定日期的时间戳
     * @param date 指定日期
     * @return 指定日期的时间戳
     */
    public static Timestamp getTimestamp(Date date) {
        return new Timestamp(date.getTime());
    }

    /**
     * 指定日历的时间戳
     * @param cal 指定日历
     * @return 指定日历的时间戳
     */
    public static Timestamp getCalendarTimestamp(Calendar cal) {
        return new Timestamp(cal.getTime().getTime());
    }


    /**
     * 系统时间的毫秒数
     * @return 系统时间的毫秒数
     */
    public static long getMillis() {
        return new Date().getTime();
    }

    /**
     * 指定日历的毫秒数
     * @param cal 指定日历
     * @return 指定日历的毫秒数
     */
    public static long getMillis(Calendar cal) {
        return cal.getTime().getTime();
    }

    /**
     * 指定日期的毫秒数
     * @param date 指定日期
     * @return 指定日期的毫秒数
     */
    public static long getMillis(Date date) {
        return date.getTime();
    }

    /**
     * 指定时间戳的毫秒数
     * @param ts 指定时间戳
     * @return 指定时间戳的毫秒数
     */
    public static long getMillis(Timestamp ts) {
        return ts.getTime();
    }

    /**
     * 获取时间字符串
     */
    public static String getDataString(SimpleDateFormat formatstr) {
        return formatstr.format(getCalendar().getTime());
    }


    /**
     * 默认日期按指定格式显示
     * @param pattern 指定的格式
     * @return 默认日期按指定格式显示
     */
    public static String formatDate(String pattern) {
        return getSDFormat(pattern).format(getCalendar().getTime());
    }

    /**
     * 指定日期按指定格式显示
     * @param cal 指定的日期
     * @param pattern 指定的格式
     * @return 指定日期按指定格式显示
     */
    public static String formatDate(Calendar cal, String pattern) {
        return getSDFormat(pattern).format(cal.getTime());
    }

    /**
     * 指定日期按指定格式显示
     * @param date 指定的日期
     * @param pattern 指定的格式
     * @return 指定日期按指定格式显示
     */
    public static String formatDate(Date date, String pattern) {
        return getSDFormat(pattern).format(date);
    }

    /**
     * 根据指定的格式将字符串转换成Date 如输入：2003-11-19 11:20:20将按照这个转成时间
     * @param src 将要转换的原始字符窜
     * @param pattern 转换的匹配格式
     * @return 如果转换成功则返回转换后的日期
     * @throws ParseException
     */
    public static Date parseDate(String src, String pattern)
            throws ParseException {
        return getSDFormat(pattern).parse(src);

    }

    /**
     * 根据指定的格式将字符串转换成Date 如输入：2003-11-19 11:20:20将按照这个转成时间
     * @param src 将要转换的原始字符窜
     * @param pattern 转换的匹配格式
     * @return 如果转换成功则返回转换后的日期
     * @throws ParseException
     */
    public static Calendar parseCalendar(String src, String pattern)
            throws ParseException {

        Date date = parseDate(src, pattern);
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return cal;
    }


    /**
     * 根据指定的格式将字符串转换成Date 如输入：2003-11-19 11:20:20将按照这个转成时间
     * @param src 将要转换的原始字符窜
     * @param pattern 转换的匹配格式
     * @return 如果转换成功则返回转换后的时间戳
     * @throws ParseException
     */
    public static Timestamp parseTimestamp(String src, String pattern)
            throws ParseException {
        Date date = parseDate(src, pattern);
        return new Timestamp(date.getTime());
    }

    /**
     * 计算两个时间之间的差值，根据标志的不同而不同
     * @param flag 计算标志，表示按照年/月/日/时/分/秒等计算
     * @param calSrc 减数
     * @param calDes 被减数
     * @return 两个日期之间的差值
     */
    public static int dateDiff(char flag, Calendar calSrc, Calendar calDes) {

        long millisDiff = getMillis(calSrc) - getMillis(calDes);

        if (flag == 'y') {
            return (calSrc.get(calSrc.YEAR) - calDes.get(calDes.YEAR));
        }

        if (flag == 'd') {
            return (int) (millisDiff / DAY_IN_MILLIS);
        }

        if (flag == 'h') {
            return (int) (millisDiff / HOUR_IN_MILLIS);
        }

        if (flag == 'm') {
            return (int) (millisDiff / MINUTE_IN_MILLIS);
        }

        if (flag == 's') {
            return (int) (millisDiff / SECOND_IN_MILLIS);
        }

        return 0;
    }
    public static int getYear(){
        GregorianCalendar calendar=new GregorianCalendar();
        calendar.setTime(getDate());
        return calendar.get(Calendar.YEAR);
    }

    /**
     * @Description: 日期加天数
     * @author Ryan
     * @date 2018/2/5 14:59
     */
    public static Date plusDay(int num,Date newDate){
        try {
            Calendar ca = Calendar.getInstance();
            ca.setTime(newDate);
            ca.add(Calendar.DATE, num);// num为增加的天数，可以改变的
            Date enddate = ca.getTime();
            return enddate;
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public static Date plusHour(int num,Date newDate){
        try {
            Calendar ca = Calendar.getInstance();
            ca.setTime(newDate);
            ca.add(Calendar.HOUR, num);// num为增加的小时数，可以改变的
            Date enddate = ca.getTime();
            return enddate;
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    /**
     * @Description: 日期加年数
     * @author Ryan
     * @date 2018/2/5 14:59
     */
    public static Date plusYear(int num,Date newDate) throws ParseException{
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Calendar ca = Calendar.getInstance();
        ca.setTime(newDate);
        ca.add(Calendar.YEAR, num);
        Date enddate = ca.getTime();
        return enddate;
    }

    /**
     * 将短时间格式时间转换为字符串 yyyyMMddHHmmss
     *
     * @param dateDate
     * @return
     */
    public static String dateToStrOrder(Date dateDate) {
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
        String dateString = format.format(dateDate);
        return dateString;
    }

    /**
     * @Description: 获取时间戳和1位随机数
     * @author Ryan
     * @date 2018/6/20 14:43
     */
    public static String getGuid() {
        long time = new Date().getTime();
        return time+""+new Random().nextInt(9);
    }

    /**
     * @Description: 十位时间戳转date
     * @author Ryan
     * @date 2018/7/9 17:22
     */
    public static Date longToDate10(Long time) {
        Date date= null;
        if (time!=null){
            SimpleDateFormat format =  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String dateString = format.format(new Date(time * 1000L));
            try {
                date = format.parse(dateString);
            } catch (ParseException e) {
                LOG.error(e);
            }
        }
        return date;
    }

    public static String formatyyyyMMdd(Date date){
        if (date != null) {
            SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
            return format.format(date);
        } else {
            return "";
        }
    }

    /**
     * @Description: 两个日期之间的天数
     * @author Ryan
     * @date 2018/8/13 16:34
     */
    public static int getDayNumber(Date date1,Date date2) {
        int a = (int) ((date1.getTime() - date2.getTime()) / (1000*3600*24));
        return a;
    }

    /**
     * @Description: java 获取当天（今日）零点零分零秒
     * @author Ryan
     * @date 2018/11/19 18:24
     */
    public static Date getTodayZeroTime(){
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        Date zero = calendar.getTime();
        return zero;
    }

    /**
     * @Description: java 获取当天（今日）零点零分零秒
     * @author Ryan
     * @date 2018/11/19 18:24
     */
    public static Date getTodayEnd(String date){
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat defaultFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        calendar.setTime(strToDate(date, defaultFormat));
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        Date end = calendar.getTime();
        return end;
    }

    public static boolean isWeekDays() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY ||
                calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
            return true;
        }
        return false;
    }

    public static String UTCStringToDefaultString(String UTCString) {
        try
        {
            if (StringUtils.isNotBlank(UTCString)){
                UTCString = UTCString.replace("Z", " UTC");
                SimpleDateFormat utcFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS Z");
                SimpleDateFormat defaultFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date date = utcFormat.parse(UTCString);
                return defaultFormat.format(date);
            }else{
                return null;
            }

        } catch(ParseException pe){
            pe.printStackTrace();
            return null;
        }
    }


    public static void main(String args[]) throws ParseException {
        System.out.println(getDayNumber(strToDate("2018-09-11",new SimpleDateFormat("yyyy-MM-dd")),strToDate("2018-09-09",new SimpleDateFormat("yyyy-MM-dd"))));
        System.out.println(plusDay(3,new Date()));
    }

}
