package com.jueran.sujiquan.controller;

import com.jueran.sujiquan.model.request.GroupSendFileUploadBody;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

@Controller
@RequestMapping("/files/v1")
public class FileController {
    private static final com.jueran.sujiquan.log.JRLog LOG = new com.jueran.sujiquan.log.JRLog(FileController.class);
    private static Gson gson = new Gson();
    @Value("${file.base.path}")
    private String fileBasePath;

    @PostMapping("/group-send-file-upload")
    public @ResponseBody void groupSendExcelUpload(@RequestParam("file") MultipartFile file,
                                                   @RequestBody GroupSendFileUploadBody body) {

        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
        Path path = Paths.get(fileBasePath + fileName);
        try {
            Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
//            new DefaultFileProcess(fileName, path.toAbsolutePath().toString(), body.getTaskName(),
//                    body.getAppName(), body.getSendDateTime(),
//                    file.getInputStream(), tblGroupSendDao, tblUploadHistoryDao);
        } catch (IOException e) {
            e.printStackTrace();
        }




    }
}
