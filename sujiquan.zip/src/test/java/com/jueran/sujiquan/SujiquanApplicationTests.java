package com.jueran.sujiquan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SujiquanApplicationTests {

    @Test
    void contextLoads() {
    }

}
